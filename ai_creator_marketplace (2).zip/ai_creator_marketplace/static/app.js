document.querySelectorAll(".flash").forEach((message) => {
  window.setTimeout(() => message.classList.add("flash-hide"), 4500);
});
