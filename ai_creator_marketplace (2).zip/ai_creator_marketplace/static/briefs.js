const generateButton = document.getElementById("generateBrief");
if (generateButton) {
  generateButton.addEventListener("click", async () => {
    const original = generateButton.innerHTML;
    generateButton.disabled = true;
    generateButton.innerHTML = "Building your draft…";
    try {
      const response = await fetch("/api/brief-builder", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
          idea: document.getElementById("roughIdea").value,
          content_type: document.getElementById("aiContentType").value,
          style: document.getElementById("aiStyle").value,
          format: document.getElementById("aiFormat").value,
          usage: document.getElementById("aiUsage").value,
          budget: document.getElementById("aiBudget").value
        })
      });
      if (!response.ok) throw new Error("Could not generate a draft");
      const draft = await response.json();
      document.getElementById("generatedTitle").textContent = draft.title;
      document.getElementById("generatedDescription").textContent = draft.description;
      document.getElementById("helperOutput").hidden = false;
      document.getElementById("helperOutput").dataset.title = draft.title;
      document.getElementById("helperOutput").dataset.description = draft.description;
    } catch (error) {
      alert("Couldn't create a draft. Please try again.");
    } finally {
      generateButton.disabled = false;
      generateButton.innerHTML = original;
    }
  });
}
document.getElementById("useDraft")?.addEventListener("click", () => {
  const output = document.getElementById("helperOutput");
  document.getElementById("title").value = output.dataset.title || "";
  document.getElementById("description").value = output.dataset.description || "";
  document.getElementById("content_type").value = document.getElementById("aiContentType").value;
  document.getElementById("style").value = document.getElementById("aiStyle").value;
  document.getElementById("format").value = document.getElementById("aiFormat").value;
  const usageMap = {
    "Paid ads and social media": "Paid ads and social media",
    "Organic social only": "Organic social only",
    "Website and e-commerce": "Website and e-commerce",
    "All digital channels": "All digital channels",
    "Print and digital": "Print and digital"
  };
  document.getElementById("usage").value = usageMap[document.getElementById("aiUsage").value] || "Discuss licensing before use";
  const budgetMap = {
    "Under ₹10,000": "Under ₹10,000",
    "₹10,000–₹25,000": "₹10,000–₹25,000",
    "₹25,000–₹50,000": "₹25,000–₹50,000",
    "₹50,000+": "₹50,000+",
    "Open to proposals": "Open to proposals"
  };
  document.getElementById("budget").value = budgetMap[document.getElementById("aiBudget").value] || "₹10,000–₹25,000";
  document.getElementById("publishForm").scrollIntoView({behavior: "smooth", block: "start"});
});
